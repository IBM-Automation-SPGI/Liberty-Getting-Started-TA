#Fri Mar 22 04:43:04 EDT 2024
lib/com.ibm.websphere.rest.api.discovery_1.0.85.jar=a35ec77bad49b03fd2468cfdf3e1c4d5
lib/features/com.ibm.websphere.appserver.autoRestHandlerApiDiscovery-1.0.mf=e3e829327d5bc090f91be3afc3a696bf
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0-javadoc.zip=f9019e7fae902fe23d2c723887b169ad
dev/spi/ibm/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0.85.jar=209e323cf6f607be864827507887c995
