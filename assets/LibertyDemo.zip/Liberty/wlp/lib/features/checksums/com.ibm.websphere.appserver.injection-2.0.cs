#Fri Mar 22 04:39:06 EDT 2024
lib/features/com.ibm.websphere.appserver.injection-2.0.mf=05aacb7a22b19f81b8f3d3131174e6ee
lib/com.ibm.ws.injection.jakarta_1.0.85.jar=c9a6d67ed3ad66672bd10b1ff7261fef
