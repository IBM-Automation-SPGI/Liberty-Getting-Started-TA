#Fri Mar 22 04:39:06 EDT 2024
lib/features/com.ibm.websphere.appserver.javaeePlatform-8.0.mf=fd260a9090757e24751c76b631704ae3
lib/com.ibm.ws.javaee.version_1.0.85.jar=9518a3ddc9bc8e72b7859b6ce51736a6
lib/com.ibm.ws.javaee.platform.v8_1.0.85.jar=7b5ef6fb21cc751409028da7de76a7fd
