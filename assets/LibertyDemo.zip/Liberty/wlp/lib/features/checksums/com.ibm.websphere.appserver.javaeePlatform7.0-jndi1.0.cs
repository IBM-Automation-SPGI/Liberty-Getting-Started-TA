#Fri Mar 22 04:43:04 EDT 2024
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=7a12cae7241b6a39bdd8fcef6d6cd598
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.85.jar=9edeaf9b3882e95827bc14b6d69d8c14
