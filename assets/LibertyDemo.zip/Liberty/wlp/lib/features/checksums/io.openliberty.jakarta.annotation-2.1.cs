#Fri Mar 22 04:39:06 EDT 2024
lib/features/io.openliberty.jakarta.annotation-2.1.mf=86674c74c9c0efcf4a8f308b5f2d2568
dev/api/spec/io.openliberty.jakarta.annotation.2.1_1.0.85.jar=8f6ff127278f9f84cbb36de3d520e08c
