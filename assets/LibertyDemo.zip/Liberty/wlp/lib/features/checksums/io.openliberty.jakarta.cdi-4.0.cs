#Fri Mar 22 04:43:03 EDT 2024
dev/api/spec/io.openliberty.jakarta.cdi.4.0_1.0.85.jar=effd03be484a2f406a6f1904e19a29cd
lib/features/io.openliberty.jakarta.cdi-4.0.mf=22586f3dc5f3ee36fbc46b0a550c0bdb
