#Fri Mar 22 04:43:04 EDT 2024
lib/features/io.openliberty.jakarta.websocket-2.1.mf=e26b817443bd6169bccef9f63ffebf9a
dev/api/spec/io.openliberty.jakarta.websocket.2.1_1.0.85.jar=31a57ebb3b47a63ebf5a70aa3cc21b85
dev/api/spec/io.openliberty.jakarta.websocket.client.2.1_1.0.85.jar=8bafb0fa9474fb172069f240615f9d31
