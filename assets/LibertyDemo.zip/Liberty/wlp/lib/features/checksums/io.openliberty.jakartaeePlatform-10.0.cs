#Fri Mar 22 04:39:06 EDT 2024
lib/features/io.openliberty.jakartaeePlatform-10.0.mf=383e2897a4c513047cc85d9f2a42883d
lib/com.ibm.ws.javaee.version_1.0.85.jar=9518a3ddc9bc8e72b7859b6ce51736a6
lib/io.openliberty.jakartaee.platform.v10_1.0.85.jar=15ece5ec76d1fcdb5a16ba7757d1fbb1
