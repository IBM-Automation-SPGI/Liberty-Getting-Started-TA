#Fri Mar 22 04:43:04 EDT 2024
dev/api/ibm/javadoc/io.openliberty.transaction_1.1-javadoc.zip=4fe60086c0219089a026fe8092682ebb
dev/api/spec/io.openliberty.jakarta.transaction.2.0_1.0.85.jar=6b6f6aa8319718d1ebf46a23b93adb99
lib/features/io.openliberty.jta-2.0.mf=3c0c3a7b314ad148828c99475bbc1092
dev/api/ibm/io.openliberty.transaction_1.1.85.jar=a7a68b4589c6767e2318c30b37684c6e
