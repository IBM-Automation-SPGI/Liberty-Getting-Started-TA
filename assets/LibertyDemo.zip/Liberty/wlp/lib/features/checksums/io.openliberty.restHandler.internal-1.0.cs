#Fri Mar 22 04:43:03 EDT 2024
lib/com.ibm.websphere.jsonsupport_1.0.85.jar=25eb692c3b4fd01d52a4d7fd8c9f69b6
lib/com.ibm.ws.org.joda.time.1.6.2_1.0.85.jar=e3c590f3908d205e3220657438e6ff35
lib/com.ibm.websphere.rest.handler_1.0.85.jar=d8172b2dc15ef548fcfd9f4528664455
lib/features/io.openliberty.restHandler.internal-1.0.mf=5e8ae2a65ee9fc981dccd34ad8d8699d
