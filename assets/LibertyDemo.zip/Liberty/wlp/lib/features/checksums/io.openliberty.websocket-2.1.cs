#Fri Mar 22 04:43:04 EDT 2024
lib/com.ibm.ws.wsoc.2.1.jakarta_1.0.85.jar=61e57a7ca7a6793a129f13e501acb994
lib/io.openliberty.wsoc.ssl.internal_1.0.85.jar=31505d374b405364652e3cc699d11f39
lib/features/io.openliberty.websocket-2.1.mf=e5c93a9c8b4d9835b228056fdbc0eea9
dev/api/ibm/io.openliberty.wsoc_1.0.85.jar=86a2c3075f4c954762625f22d5295e7a
dev/api/ibm/javadoc/io.openliberty.wsoc_1.0-javadoc.zip=187bc6ac2697d6dbdf4b1be8609bdcf7
lib/com.ibm.ws.wsoc.jakarta_1.0.85.jar=674dc762e9c8ce9750cd8d10202a125c
lib/io.openliberty.wsoc.2.1.internal_1.0.85.jar=b10c8b07b274fd8d0f3e73bad3542dfb
